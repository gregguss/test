<div wire:offline class="flex flex-row justify-center items-center w-full bg-red-700 p-3 text-white rounded-md">
   <span class="inline-flex items-center">
       <x-tabler-wifi-off class="w-5 h-5 mr-2" />
       {{ __('No Internet Connection') }}
   </span>
</div>