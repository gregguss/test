@extends('layout.error')

@section('error_code', '419')
@section('error_title', __('Your token has been expired. Please go previous page and reload.'))
@section('error_subtitle', __('If this is an error it will be logged and our technic team will resolve it shortly.'))
