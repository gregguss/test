@extends('panel.layout.app', ['disable_tblr' => true])
@section('title', __('test'))
@section('titlebar_actions', '')

@section('content')

@endsection
