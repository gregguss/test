<div id="loading-spinner"
     class="spinner-border text-primary fixed top-1/2 left-1/2 z-[1000]"
     role="status"
     style="display:none">
    <span class="sr-only">Loading...</span>
</div>