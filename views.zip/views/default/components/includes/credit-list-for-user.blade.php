<x-credit-list
	class:legends="gap-1"
	class:modal-trigger="text-2xs w-full"
	modal-trigger-variant="ghost-shadow"
	modal-trigger-pos="block"
	expanded-modal-trigger
/>
