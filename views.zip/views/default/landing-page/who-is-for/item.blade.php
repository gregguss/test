<x-color-box
    title="{!! __($item->title) !!}"
    color="{{ $item->color }}"
/>
