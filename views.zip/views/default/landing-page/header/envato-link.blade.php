<div class="fixed bottom-8 start-8 z-50">
    <a
        class="size-12 inline-flex items-center justify-center rounded-full bg-[#262626] transition-all duration-300 hover:-translate-y-1 hover:scale-110 hover:shadow-md"
        href="https://codecanyon.net/item/magicai-openai-content-text-image-chat-code-generator-as-saas/45408109"
        target="_blank"
        title="{{ __('Buy on Envato') }}"
    >
        <svg
            fill="#0ac994"
            xmlns="http://www.w3.org/2000/svg"
            width="19.824"
            height="22.629"
            viewBox="0 0 19.824 22.629"
        >
            <path
                d="M17.217,9.263c-.663-.368-2.564-.14-4.848.566-4,2.731-7.369,6.756-7.6,13.218-.043.155-.437-.021-.515-.069a9.2,9.2,0,0,1-.606-7.388c.168-.28-.381-.624-.48-.525A11.283,11.283,0,0,0,1.6,17.091a9.84,9.84,0,0,0,17.2,9.571c3.058-5.481.219-16.4-1.574-17.4Z"
                transform="translate(-0.32 -9.089)"
            />
        </svg>
    </a>
</div>
