<div class="w-full shrink-0 grow-0 basis-full">
    <blockquote class="max-sm:mb-7">
        <p>{!! __('“' . $item->words . '”') !!}</p>
    </blockquote>
</div>
